#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "mesh.h"
#include "renderer.h"
#include "texture.h"

#include "platform/display.h"
#include "platform/profiler.h"

#include "xtime_l.h"  // XTime_GetTime, COUNTS_PER_SECOND
#include "ff.h"       // FatFs main header





//----------------APP-----------------
Camera cam;
Mesh  *teapotMesh, *knightMesh;
Texture *teapotTex, *teapotNormTex, *knightTex, *knightNormTex;
Vec3 pos = { 0,0,0 };
Vec3 rot = { 90,0,0 };


void Game_Init(const Display* display){
	int W, H;
	Display_GetResolution(display, &W, &H) ;
    cam = camera_create( (Vec3){0,0,0}, 0, 0, deg2radf(60), (float)W/H, 0.1f, 100);
    camera_rotate(&cam, 0, deg2radf(35));
    camera_move(&cam, CAM_BACKWARD, 5);


    //Load Meshes
    teapotMesh = LoadMesh("0:/Teapot/TEAPOT.MSH");
    knightMesh = LoadMesh("0:/Knight/KNIGHT.MSH");

    //Load Textures
    teapotTex      = TextureLoad("0:/Teapot/D.bmp", 0);
    teapotNormTex  = TextureLoad("0:/Teapot/N.bmp", 0);
    knightTex      = TextureLoad("0:/Knight/D.bmp", 0);
    knightNormTex  = TextureLoad("0:/Knight/N.bmp", 0);

    PrintMesh(knightMesh, 0);
}

void Game_Update(float dt){
    const float rotSpeed = 0;

	rot.x -= rotSpeed * dt;
}

void Game_Render(Framebuffer* frameBuf){
    ClearBuffers(frameBuf, color_rgb(30,30,30));

    DrawMesh(frameBuf, teapotMesh, pos, rot, vec3(1 ,1 ,1), &cam, teapotTex, teapotNormTex, color_rgb(150, 0, 0));

}

void Game_Shutdown(){
    FreeMesh(teapotMesh);
    FreeMesh(knightMesh);
    TextureFree(teapotTex); TextureFree(teapotNormTex);
    TextureFree(knightTex); TextureFree(knightNormTex);
}









///////////////////////////////////////////////////////////////////////////////////////////
//MAIN
int main(){
    printf("App started\n\r");


    // Mount SD card
    FATFS fs;
    FRESULT fres = f_mount(&fs, "0:", 1);
    if (fres != FR_OK) {
        printf("SD card mount failed (%d)\n", fres);
        return -1;
    }
    printf("SD card mount successful\n");


	//Initialize HDMI Drivers
    Display* display = Display_Create(1280, 720);



    //MAIN LOOP
    _PROF_BEGIN("Main");
    const double cps = (double)COUNTS_PER_SECOND;
    XTime tPrev, tNow;
    XTime_GetTime(&tPrev);
    uint64_t frameNo = 0;


    Game_Init(display);
    while(1){  //platform.running) {
    	XTime_GetTime(&tNow);
    	double dt = (double)(tNow - tPrev) / cps;
    	tPrev = tNow;

    	if((frameNo&63) == 0)
    		printf("Delta Time: %f   FPS: %d\n", dt, (int)(1/dt));

    	//if(frameNo==300)
    	//	break;

        Game_Update(dt);

        _PROF_BEGIN("Display_AcquireFrame");
        Framebuffer frameBuf = Display_AcquireFrame(display);
        _PROF_END("Display_AcquireFrame");

        _PROF_BEGIN("Game_Render");
        Game_Render(&frameBuf);
        _PROF_END("Game_Render");

        _PROF_BEGIN("Display_Present");
        Display_Present(display, &frameBuf);
        _PROF_END("Display_Present");

        frameNo+=1;
    }
    _PROF_END("Main");
    ProfShowStats_UART();
    Game_Shutdown();
    Display_Destroy(display);
    printf("Successfully ran application");
    return 0;
}

