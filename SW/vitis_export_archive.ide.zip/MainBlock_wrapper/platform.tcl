# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct D:\VitisWorkspace\MainBlock_wrapper\platform.tcl
# 
# OR launch xsct and run below command.
# source D:\VitisWorkspace\MainBlock_wrapper\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {MainBlock_wrapper}\
-hw {C:\Users\Victor K\Desktop\AMD Repo\HW\MainBlock_wrapper.xsa}\
-out {D:/VitisWorkspace}

platform write
domain create -name {standalone_ps7_cortexa9_0} -display-name {standalone_ps7_cortexa9_0} -os {standalone} -proc {ps7_cortexa9_0} -runtime {cpp} -arch {32-bit} -support-app {empty_application}
platform generate -domains 
platform active {MainBlock_wrapper}
domain active {zynq_fsbl}
domain active {standalone_ps7_cortexa9_0}
platform generate -quick
bsp reload
bsp reload
bsp setlib -name xilffs -ver 5.3
bsp write
bsp reload
catch {bsp regenerate}
bsp config use_strfunc "2"
bsp write
bsp reload
catch {bsp regenerate}
platform generate
platform generate
