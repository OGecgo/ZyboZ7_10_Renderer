# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: D:\VitisWorkspace\Renderer_system\_ide\scripts\debugger_renderer-default.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source D:\VitisWorkspace\Renderer_system\_ide\scripts\debugger_renderer-default.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Digilent Zybo Z7 210351A818FFA" && level==0 && jtag_device_ctx=="jsn-Zybo Z7-210351A818FFA-13722093-0"}
fpga -file D:/VitisWorkspace/Renderer/_ide/bitstream/MainBlock_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw D:/VitisWorkspace/MainBlock_wrapper/export/MainBlock_wrapper/hw/MainBlock_wrapper.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source D:/VitisWorkspace/Renderer/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow D:/VitisWorkspace/Renderer/Release/Renderer.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
